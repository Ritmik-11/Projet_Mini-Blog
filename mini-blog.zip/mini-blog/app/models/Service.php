<?php

class Service {
    // Ajout de la logique d'enregistrement des demandes ici plus tard
}
