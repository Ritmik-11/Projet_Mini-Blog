<?php

require_once 'models/Service.php';

class ServiceController {
    public function index() {
        require 'views/service/index.php';
    }
}
